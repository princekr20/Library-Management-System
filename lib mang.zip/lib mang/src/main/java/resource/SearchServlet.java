package resource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // JDBC URL, username, and password
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/librarymanagementsystem";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "2003";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve search query from request parameter
        String query = request.getParameter("query");

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the database connection
            try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
                String sql = "SELECT * FROM insertbook WHERE book_name LIKE ? OR author_name LIKE ?";
                try (PreparedStatement statement = conn.prepareStatement(sql)) {
                    statement.setString(1, "%" + query + "%");
                    statement.setString(2, "%" + query + "%");

                    // Execute the query
                    try (ResultSet resultSet = statement.executeQuery()) {
                        // Forward the result set to the JSP page for rendering
                        request.setAttribute("resultSet", resultSet);
                        request.getRequestDispatcher("search-results.jsp").forward(request, response);
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            response.sendRedirect("search.jsp?error=database");
        }
    }
}
