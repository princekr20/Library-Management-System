package resource;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/InsertBookServlet")
public class InsertBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    // JDBC URL, username, and password
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/librarymanagementsystem";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "2003";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String bookName = request.getParameter("bookName");
        String authorName = request.getParameter("authorName");
        String edition = request.getParameter("edition");

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the database connection
            try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
                String sql = "INSERT INTO insertbook (book_name, author_name, edition) VALUES (?, ?, ?)";
                try (PreparedStatement statement = conn.prepareStatement(sql)) {
                    statement.setString(1, bookName);
                    statement.setString(2, authorName);
                    statement.setString(3, edition);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        // Data inserted successfully
                        response.sendRedirect("book-insert-success.jsp");
                    } else {
                        // Failed to insert data
                        response.sendRedirect("book-insert-failure.jsp");
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            // Redirect to error page if an exception occurs
            response.sendRedirect("insertbook.jsp?error=database");
        }
    }
}
