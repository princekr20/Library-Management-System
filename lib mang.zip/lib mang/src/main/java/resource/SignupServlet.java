package resource;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SignupServlet")
public class SignupServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	// JDBC URL, username, and password
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/librarymanagementsystem";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "2003";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String email = request.getParameter("email");
        String password = request.getParameter("pass");

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the database connection
            try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
                String sql = "INSERT INTO users (fname, lname, email, password) VALUES (?, ?, ?, ?)";
                try (PreparedStatement statement = conn.prepareStatement(sql)) {
                    statement.setString(1, fname);
                    statement.setString(2, lname);
                    statement.setString(3, email);
                    statement.setString(4, password);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        // Data inserted successfully
                        response.sendRedirect("signup-success.jsp");
                    } else {
                        // Failed to insert data
                        response.sendRedirect("signup-failure.jsp");
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            // Redirect to error page if an exception occurs
            response.sendRedirect("error.jsp");
        }
    }
}
